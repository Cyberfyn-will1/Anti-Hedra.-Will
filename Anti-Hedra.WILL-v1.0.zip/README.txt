===============================
🛡️ ANTI-HEDRA.WILL v1.0
===============================

Creator: FYN  
Purpose: Detect spyware, remote access tools, and Hedra-like threats.

📁 CONTENTS:
- antihedra.sh → scanner script  
- hedra_signatures.txt → known threat names  
- protect_guide.txt → safety advice  
- logs/ → saved scan results

💡 INSTRUCTIONS:
1. Run in Termux using: bash antihedra.sh  
2. Results appear in logs/scan_log.txt

⚠️ TERMS:
Educational use only. Don’t use to spy or hack.
Stay safe, stay smart.

– FYN
