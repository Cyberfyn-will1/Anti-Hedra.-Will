#!/bin/bash
# Anti-Hedra.WILL v1.0 - Made by FYN

echo "🛡️ Starting Anti-Hedra.WILL scan..."

# Check installed apps
echo "[+] Checking apps..."
pm list packages > installed_apps.txt
grep -Ei 'spy|rat|keylogger|meterpreter|hidra|farm|shell' installed_apps.txt > detected_apps.txt

# Check processes
echo "[+] Checking background processes..."
ps -A > all_processes.txt
grep -Ei 'nc|rport|meterpreter|keylogger|tcp|hidra' all_processes.txt > detected_procs.txt

# Check suspicious ports
echo "[+] Checking open ports..."
netstat -an | grep -E ':4444|:5555|:8080|:9999' > suspicious_ports.txt

# Save logs
mkdir -p logs
cat detected_apps.txt detected_procs.txt suspicious_ports.txt > logs/scan_log.txt
echo "[✔] Scan finished. Logs saved in logs/scan_log.txt"
